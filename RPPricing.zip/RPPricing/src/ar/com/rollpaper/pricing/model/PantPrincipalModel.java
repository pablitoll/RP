package ar.com.rollpaper.pricing.model;

import ar.com.rp.ui.pantalla.BaseModel;


public class PantPrincipalModel extends BaseModel { 
	}
