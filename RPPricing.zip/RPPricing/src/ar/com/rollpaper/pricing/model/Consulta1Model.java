package ar.com.rollpaper.pricing.model;

import ar.com.rp.ui.pantalla.BaseModel;

public class Consulta1Model extends BaseModel{

}
