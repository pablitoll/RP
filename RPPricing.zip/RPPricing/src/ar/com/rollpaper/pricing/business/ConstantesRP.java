package ar.com.rollpaper.pricing.business;


public class ConstantesRP {

	public enum Acciones {
		CALCULADORA, SALIR, CONSULTA1
	}

	public static String IMG_ICONO_APP = "/resource/vector.png";
	public static String IMG_EXIT = "/resource/exit.png";
	public static String IMG_CAL = "/resource/calculadora.png";	 

}
