package ar.com.rollpaper.pricing.view;

import ar.com.rp.ui.pantalla.BaseViewMVCExtendida;

public class Consulta1View extends BaseViewMVCExtendida {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Consulta1View() throws Exception {
		super();
		setTitle("Consulta 1");
	}

	@Override
	public void asignarBotonesPantExtendida() {
		// TODO Auto-generated method stub
		
	}

}
